vulnerable-project.git

Project with vulnerability against which the dependency checker would be run.